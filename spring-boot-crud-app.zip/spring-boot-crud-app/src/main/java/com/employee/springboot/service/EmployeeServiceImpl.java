package com.employee.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.employee.springboot.entity.Employee;
import com.employee.springboot.repository.EmployeeRepository;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
 
	@Autowired 
	EmployeeRepository employeeRepository;

	@Override
	public List<Employee> getAllEmployee() {
		return employeeRepository.findAll();
	}

	@Override
	public Employee getEmployeeById(long id) {
		return employeeRepository.findById(id).get();
	}

	@Override
	public Employee getEmployeeByEmail(String email) {
		return employeeRepository.findByEmail(email);
	}

	@Override
	public void saveOrUpdateEmployee(Employee employee) {
		employeeRepository.save(employee);
	}

	@Override
	public void deleteEmployee(long id) {
		employeeRepository.deleteById(id);
	}

	@Override
	public List<Employee> search(String keyword) {
		return employeeRepository.search(keyword);
	}

	@Override
	public List<Employee> getEmployeeByEmpId(String empId) {
		return employeeRepository.findEmployeeByEmpId(empId);
	}

	@Override
	public Employee checkLogin(String email, String password) {
		return employeeRepository.validateEmployee(email, password);
	}

	@Override
	public String getEmployeePassword(String email) {
		return employeeRepository.findEmployeePassword(email);
	}

	@Override
	public void deleteAllEmployee() {
		employeeRepository.deleteAll();	
	}

}